import React from 'react';

export default class Footer extends React.Component{

  render(){
    return(
      <footer className="main-footer">
        <div className="pull-right hidden-xs">
        </div>
        <strong>Copyright © 2018 <a href="">Cultivating Mind</a></strong> All rights
        reserved.
        <div>
        <strong>Design & Developed by <a href="#">AVAComp Pvt Ltd</a></strong>
        </div>
      </footer>
    );
  }
}
